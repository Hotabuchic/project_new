Authors and Contributors
========================

* Mikhail Korobov;
* @radixvinni;
* @ivirabyan;
* @anti-social;
* @insolor.

If you contributed to pymorphy2, please add yourself to this list
(or update your contact information).

Many people contributed to pymorphy2 predecessor, pymorphy; they are
listed here: https://github.com/kmike/pymorphy/blob/master/AUTHORS.rst
